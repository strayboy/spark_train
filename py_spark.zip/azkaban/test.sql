select deptno,count(1) from emp group by deptno;
